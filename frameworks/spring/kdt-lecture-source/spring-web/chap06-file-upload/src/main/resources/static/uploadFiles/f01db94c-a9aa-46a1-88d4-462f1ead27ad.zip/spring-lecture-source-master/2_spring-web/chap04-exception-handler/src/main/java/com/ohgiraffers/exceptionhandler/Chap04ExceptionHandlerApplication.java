package com.ohgiraffers.exceptionhandler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap04ExceptionHandlerApplication {

    public static void main(String[] args) {
        SpringApplication.run(Chap04ExceptionHandlerApplication.class, args);
    }

}
