package com.ohgiraffers.fileupload;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@Controller
public class FileUploadController {

    @PostMapping("/single-file")
    public String singleFileUpload(
            @RequestParam String singleFileDescription,
            @RequestParam MultipartFile singleFile
            ) {

        System.out.println("singleFileDescrption : " + singleFileDescription);
        System.out.println("singleFile : " + singleFile);

        /* 서버로 전달 된 MultipartFile 객체를 설정하는 경로에 저장한다. */
        String root = "src/main/resources/static";
        String filePath = root + "/uploadFiles";
        File dir = new File(filePath);

        if(!dir.exists()) dir.mkdirs();

        /* 파일명이 중복 되면 덮어쓰기 될 수 있으므로 중복 되지 않는 이름으로 변경 처리 */
        String originFileName = singleFile.getOriginalFilename();   // 업로드 파일명
        String ext = originFileName.substring(originFileName.lastIndexOf(".")); // 업로드 파일명에서 확장자 분리
        String savedName = UUID.randomUUID() + ext; // 고유한 파일명 생성 + 확장자 추가

        /* 파일 저장 */
        try {
            singleFile.transferTo(new File(filePath + "/" + savedName));
        } catch (IOException e) {

        }

        return "result";
    }
}
