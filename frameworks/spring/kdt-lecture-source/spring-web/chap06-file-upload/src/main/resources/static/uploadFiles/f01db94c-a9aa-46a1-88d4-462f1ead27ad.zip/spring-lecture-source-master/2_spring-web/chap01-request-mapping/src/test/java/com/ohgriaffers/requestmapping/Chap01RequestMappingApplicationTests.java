package com.ohgriaffers.requestmapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chap01RequestMappingApplicationTests {

    @Test
    void contextLoads() {
    }

}
