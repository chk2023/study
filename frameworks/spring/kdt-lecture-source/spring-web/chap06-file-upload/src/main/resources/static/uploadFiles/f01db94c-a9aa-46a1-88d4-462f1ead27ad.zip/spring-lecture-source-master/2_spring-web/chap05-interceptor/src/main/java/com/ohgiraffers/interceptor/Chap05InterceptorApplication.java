package com.ohgiraffers.interceptor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap05InterceptorApplication {

    public static void main(String[] args) {
        SpringApplication.run(Chap05InterceptorApplication.class, args);
    }

}
