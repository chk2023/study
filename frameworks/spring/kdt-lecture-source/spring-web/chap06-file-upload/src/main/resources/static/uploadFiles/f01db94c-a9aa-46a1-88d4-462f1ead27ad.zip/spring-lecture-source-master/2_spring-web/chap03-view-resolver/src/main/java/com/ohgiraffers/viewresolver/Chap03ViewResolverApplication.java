package com.ohgiraffers.viewresolver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap03ViewResolverApplication {

    public static void main(String[] args) {
        SpringApplication.run(Chap03ViewResolverApplication.class, args);
    }

}
