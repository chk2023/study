package com.ohgiraffers.fileupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chap06FileUploadApplicationTests {

    @Test
    void contextLoads() {
    }

}
