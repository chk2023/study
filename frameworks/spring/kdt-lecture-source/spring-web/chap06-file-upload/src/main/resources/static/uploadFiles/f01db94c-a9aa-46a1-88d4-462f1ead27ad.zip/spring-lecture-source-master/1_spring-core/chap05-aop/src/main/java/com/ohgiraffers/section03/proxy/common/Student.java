package com.ohgiraffers.section03.proxy.common;

public interface Student {
    void study(int hours);
}
