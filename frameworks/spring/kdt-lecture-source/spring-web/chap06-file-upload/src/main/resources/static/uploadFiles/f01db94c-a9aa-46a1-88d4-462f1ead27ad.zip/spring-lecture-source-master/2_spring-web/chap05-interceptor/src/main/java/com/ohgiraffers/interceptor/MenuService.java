package com.ohgiraffers.interceptor;

import org.springframework.stereotype.Service;

@Service
public class MenuService {

    public void method() {
        System.out.println("MenuService의 Method 호출 확인");
    }
}
