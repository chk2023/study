package com.ohgiraffers.exceptionhandler;

/* 문제 : extends Throwable로 처리할 경우 전역 @ExceptionHandler(MemberRegistException.class) 메소드로 처리되지 않고
* @ExceptionHandler(Exception.class) 메소드로 처리 됨
* 원인 : 발생한 Exception이 DispatcherServlet까지 던져지고 Throwable 타입의 경우 IllegalStateException 타입으로 변경 되어 처리 되기 때문임
* 해결 : extends Throwable -> extends Exception 으로 처리해야 해당 타입 객체로 보존 되어 처리 됨 */

//public class MemberRegistException extends Throwable {
public class MemberRegistException extends Exception {
    public MemberRegistException(String message) {
        super(message);
    }
}
