package com.ohgiraffers.interceptor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chap05InterceptorApplicationTests {

    @Test
    void contextLoads() {
    }

}
