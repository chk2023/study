package com.ohgiraffers.section02.common;

public interface Pokemon {

    void attack();
}
