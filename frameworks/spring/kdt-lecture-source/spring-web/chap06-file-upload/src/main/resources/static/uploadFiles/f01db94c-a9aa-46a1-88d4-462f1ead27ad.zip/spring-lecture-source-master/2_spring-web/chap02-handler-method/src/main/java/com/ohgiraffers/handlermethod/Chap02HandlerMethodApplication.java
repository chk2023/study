package com.ohgiraffers.handlermethod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap02HandlerMethodApplication {

    public static void main(String[] args) {
        SpringApplication.run(Chap02HandlerMethodApplication.class, args);
    }

}
